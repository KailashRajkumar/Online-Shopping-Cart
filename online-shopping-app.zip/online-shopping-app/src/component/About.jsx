import React from 'react';

const About = () => {
  return (
    <div className="container d-flex flex-column justify-content-center align-items-center pt-5">
      <h1 className="text-center">About</h1>
      <p className="mx-auto col-10 col-md-8 col-lg-6">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum ac sapien ac tellus luctus semper.
        Pellentesque rutrum dolor quis mollis ultrices. Nulla facilisi. Nullam tempus dapibus purus, eu cursus quam
        tincidunt at. Aliquam pulvinar sollicitudin velit, et tincidunt purus mollis ac. Duis tincidunt risus ut
        vulputate varius. Vivamus faucibus mauris sed tristique vulputate. Nunc quis ante quis nunc interdum
        vestibulum nec ac felis. Sed id ligula quis arcu congue tristique.
      </p>
    </div>
  );
};

export default About;
