import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-white fixed-bottom">
      <div className="text-center py-2">© 2023 Copyright UAE COLLECTION
      </div>
    </footer>
  );
};

export default Footer;
